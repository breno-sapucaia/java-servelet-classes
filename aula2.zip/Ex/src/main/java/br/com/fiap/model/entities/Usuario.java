package br.com.fiap.model.entities;

public class Usuario {
	public String nome,login,senha;
}
