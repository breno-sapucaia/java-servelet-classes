
public class Usuario {
	public Strig nome,login,senha;
}
