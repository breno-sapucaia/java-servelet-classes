package com.fiap.Empresa.models.entities;

public class Empresa {
	public long codigo;
	public String nome;
}
